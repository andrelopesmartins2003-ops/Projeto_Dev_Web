// Importa funcionalidades de autorização, necessárias para restringir o acesso por cargos/roles.
using Microsoft.AspNetCore.Authorization;
// Importa tipos MVC, como IActionResult, usados para devolver respostas das páginas.
using Microsoft.AspNetCore.Mvc;
// Importa a classe PageModel, base dos ficheiros code-behind das Razor Pages.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa o serviço IHubContext, usado para comunicar com clientes SignalR.
using Microsoft.AspNetCore.SignalR;
// Importa o contexto da base de dados da aplicação.
using Projeto.Data;
// Importa o Hub de notificações em tempo real usado pela aplicação.
using Projeto.Hubs;
// Importa os modelos da aplicação, incluindo o modelo Race.
using Projeto.Models;

// Define que esta classe pertence ao namespace das páginas relacionadas com corridas.
namespace Projeto.Pages.Races;

// Garante que apenas utilizadores autenticados com o papel "Admin" podem aceder a esta página.
[Authorize(Roles = "Admin")]
// Classe responsável pela lógica da página Create.cshtml, usada para criar uma nova corrida.
public class CreateModel : PageModel
{
    // Guarda uma referência ao contexto da base de dados para permitir inserir corridas.
    private readonly ApplicationDbContext _context;

    // Guarda uma referência ao Hub SignalR para enviar notificações em tempo real.
    private readonly IHubContext<NotificationHub> _hubContext;

    // Construtor chamado automaticamente pelo ASP.NET Core através de injeção de dependências.
    public CreateModel(ApplicationDbContext context, IHubContext<NotificationHub> hubContext)
    {
        // Atribui o contexto recebido à variável privada para ser usado nos métodos da página.
        _context = context;

        // Atribui o Hub recebido à variável privada para permitir enviar notificações.
        _hubContext = hubContext;
    }

    // Liga os dados submetidos no formulário HTML à propriedade Race.
    [BindProperty]
    // Objeto que representa a corrida que será preenchida pelo formulário e guardada na base de dados.
    public Race Race { get; set; } = new();

    // Método executado quando a página é aberta através de um pedido GET.
    public IActionResult OnGet()
    {
        // Devolve a própria página para mostrar o formulário de criação ao utilizador.
        return Page();
    }

    // Método executado quando o formulário é submetido através de POST.
    public async Task<IActionResult> OnPostAsync()
    {
        // Verifica se os dados submetidos respeitam as validações definidas no modelo Race.
        if (!ModelState.IsValid)
        {
            // Se houver erros de validação, volta a mostrar o formulário com as mensagens de erro.
            return Page();
        }

        // Adiciona a nova corrida ao conjunto de corridas que será guardado pelo Entity Framework.
        _context.Races.Add(Race);

        // Guarda efetivamente a nova corrida na base de dados de forma assíncrona.
        await _context.SaveChangesAsync();

        // Envia uma notificação em tempo real a todos os clientes ligados ao Hub SignalR.
        await _hubContext.Clients.All.SendAsync(
            // Nome do método JavaScript que os clientes devem ter para receber a notificação.
            "ReceiveNotification",
            // Mensagem enviada aos utilizadores, incluindo o nome do Grande Prémio criado.
            $"Nova corrida criada: {Race.GrandPrixName}"
        );

        // Após guardar com sucesso, redireciona o utilizador para a listagem de corridas.
        return RedirectToPage("Index");
    }
}
