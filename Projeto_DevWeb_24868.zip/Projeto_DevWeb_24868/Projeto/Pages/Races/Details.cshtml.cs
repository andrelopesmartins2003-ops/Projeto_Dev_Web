// Importa tipos MVC, como IActionResult.
using Microsoft.AspNetCore.Mvc;
// Importa a classe base PageModel das Razor Pages.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa o contexto da base de dados da aplicação.
using Projeto.Data;
// Importa o modelo Race.
using Projeto.Models;

// Define que esta classe pertence às páginas relacionadas com corridas.
namespace Projeto.Pages.Races;

// Classe responsável pela lógica da página Details.cshtml, usada para mostrar os dados de uma corrida.
public class DetailsModel : PageModel
{
    // Contexto da base de dados usado para procurar a corrida pelo seu id.
    private readonly ApplicationDbContext _context;

    // Construtor que recebe o contexto da base de dados por injeção de dependências.
    public DetailsModel(ApplicationDbContext context)
    {
        // Guarda o contexto recebido para ser usado no método OnGetAsync.
        _context = context;
    }

    // Propriedade que guarda a corrida encontrada; pode ser null se o id não existir.
    public Race? Race { get; set; }

    // Método executado quando a página de detalhes é aberta com um determinado id.
    public async Task<IActionResult> OnGetAsync(int id)
    {
        // Procura na tabela de corridas a corrida correspondente ao id recebido na rota.
        Race = await _context.Races.FindAsync(id);

        // Verifica se não foi encontrada nenhuma corrida.
        if (Race == null)
        {
            // Devolve uma resposta 404 para indicar que o recurso não existe.
            return NotFound();
        }

        // Devolve a página com a corrida preenchida para ser apresentada no HTML.
        return Page();
    }
}
