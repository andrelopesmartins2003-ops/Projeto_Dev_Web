// Importa as bibliotecas necessárias para esta página.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa as bibliotecas necessárias para esta página.
using Microsoft.EntityFrameworkCore;
// Importa as bibliotecas necessárias para esta página.
using Projeto.Data;

// Define o namespace onde esta página está organizada.
namespace Projeto.Pages.RaceDrivers;

// Classe responsável pela lógica desta Razor Page.
public class IndexModel : PageModel
{
// Contexto da base de dados utilizado para comunicar com o Entity Framework.
    private readonly ApplicationDbContext _context;

    public IndexModel(ApplicationDbContext context)
    {
        _context = context;
    }

    public IList<RaceResult> Races { get; set; } = new List<RaceResult>();

// Executado quando a página é aberta pelo utilizador.
    public async Task OnGetAsync()
    {
        Races = await _context.Races
            .Include(r => r.RaceDrivers)
                .ThenInclude(rd => rd.Driver)
            .OrderBy(r => r.Date)
            .Select(r => new RaceResult
            {
                Id = r.Id,
                GrandPrixName = r.GrandPrixName,
                Date = r.Date,
                Circuit = r.Circuit,
                Winner = r.RaceDrivers
                    .Where(rd => rd.Position == "1")
                    .Select(rd => rd.Driver!.Name)
                    .FirstOrDefault() ?? "Sem vencedor"
            })
            .ToListAsync();
    }

// Classe responsável pela lógica desta Razor Page.
    public class RaceResult
    {
        public int Id { get; set; }

        public string GrandPrixName { get; set; } = "";

        public DateTime Date { get; set; }

        public string Circuit { get; set; } = "";

        public string Winner { get; set; } = "";
    }
}