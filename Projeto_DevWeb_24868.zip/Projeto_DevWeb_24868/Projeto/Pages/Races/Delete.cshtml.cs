// Importa funcionalidades de autorização para limitar ações a certos utilizadores.
using Microsoft.AspNetCore.Authorization;
// Importa tipos MVC, como IActionResult.
using Microsoft.AspNetCore.Mvc;
// Importa a classe base PageModel das Razor Pages.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa o contexto da base de dados da aplicação.
using Projeto.Data;
// Importa os modelos da aplicação, incluindo Race.
using Projeto.Models;

// Define que esta classe pertence ao conjunto de páginas de corridas.
namespace Projeto.Pages.Races;

// Restringe o acesso desta página a utilizadores com o papel "Admin".
[Authorize(Roles = "Admin")]
// Classe responsável pela lógica da página Delete.cshtml, usada para confirmar e eliminar uma corrida.
public class DeleteModel : PageModel
{
    // Contexto da base de dados usado para procurar e remover corridas.
    private readonly ApplicationDbContext _context;

    // Construtor que recebe o contexto da base de dados por injeção de dependências.
    public DeleteModel(ApplicationDbContext context)
    {
        // Guarda o contexto recebido para ser usado nos métodos OnGetAsync e OnPostAsync.
        _context = context;
    }

    // Permite associar a corrida recebida/encontrada à página Razor.
    [BindProperty]
    // Propriedade que guarda a corrida a apresentar ou eliminar; pode ser null se não existir.
    public Race? Race { get; set; }

    // Método executado quando o utilizador abre a página de eliminação de uma corrida.
    public async Task<IActionResult> OnGetAsync(int id)
    {
        // Procura na base de dados a corrida com o id recebido pela rota.
        Race = await _context.Races.FindAsync(id);

        // Verifica se a corrida não foi encontrada.
        if (Race == null)
        {
            // Devolve erro 404 quando não existe nenhuma corrida com esse id.
            return NotFound();
        }

        // Mostra a página de confirmação da eliminação com os dados da corrida encontrada.
        return Page();
    }

    // Método executado quando o utilizador confirma a eliminação através do formulário POST.
    public async Task<IActionResult> OnPostAsync(int id)
    {
        // Volta a procurar a corrida pelo id para garantir que ainda existe antes de eliminar.
        var race = await _context.Races.FindAsync(id);

        // Verifica se a corrida já não existe na base de dados.
        if (race == null)
        {
            // Devolve erro 404 se a corrida não for encontrada.
            return NotFound();
        }

        // Marca a corrida encontrada para ser removida da base de dados.
        _context.Races.Remove(race);

        // Confirma a remoção na base de dados de forma assíncrona.
        await _context.SaveChangesAsync();

        // Depois da eliminação, redireciona o utilizador para a lista de corridas.
        return RedirectToPage("Index");
    }
}
