// Importa funcionalidades de autorização, usadas para limitar o acesso a administradores.
using Microsoft.AspNetCore.Authorization;
// Importa tipos MVC, como IActionResult.
using Microsoft.AspNetCore.Mvc;
// Importa a classe base PageModel das Razor Pages.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa o contexto da base de dados da aplicação.
using Projeto.Data;
// Importa o modelo Race.
using Projeto.Models;

// Define que esta classe pertence ao namespace das páginas de corridas.
namespace Projeto.Pages.Races;

// Garante que apenas utilizadores com o papel "Admin" podem editar corridas.
[Authorize(Roles = "Admin")]
// Classe responsável pela lógica da página Edit.cshtml, usada para editar uma corrida existente.
public class EditModel : PageModel
{
    // Contexto da base de dados usado para procurar e atualizar corridas.
    private readonly ApplicationDbContext _context;

    // Construtor que recebe o contexto da base de dados por injeção de dependências.
    public EditModel(ApplicationDbContext context)
    {
        // Guarda o contexto recebido numa variável privada da classe.
        _context = context;
    }

    // Liga automaticamente os campos submetidos no formulário à propriedade Race.
    [BindProperty]
    // Objeto que contém os dados da corrida a editar.
    public Race Race { get; set; } = new();

    // Método executado quando o utilizador abre a página de edição de uma corrida.
    public async Task<IActionResult> OnGetAsync(int id)
    {
        // Procura na base de dados a corrida correspondente ao id recebido na rota.
        var race = await _context.Races.FindAsync(id);

        // Verifica se não existe corrida com esse id.
        if (race == null)
        {
            // Devolve erro 404 se a corrida não for encontrada.
            return NotFound();
        }

        // Copia a corrida encontrada para a propriedade usada pela página Razor.
        Race = race;

        // Mostra a página já preenchida com os dados atuais da corrida.
        return Page();
    }

    // Método executado quando o formulário de edição é submetido.
    public async Task<IActionResult> OnPostAsync()
    {
        // Verifica se os dados enviados cumprem as regras de validação do modelo.
        if (!ModelState.IsValid)
        {
            // Se os dados forem inválidos, volta a mostrar a página com os erros.
            return Page();
        }

        // Marca a corrida recebida do formulário como alterada no Entity Framework.
        _context.Races.Update(Race);

        // Guarda as alterações na base de dados de forma assíncrona.
        await _context.SaveChangesAsync();

        // Depois de guardar, redireciona o utilizador para a página de listagem.
        return RedirectToPage("Index");
    }
}
