// Importa a classe PageModel, usada como base das Razor Pages.
using Microsoft.AspNetCore.Mvc.RazorPages;
// Importa funcionalidades assíncronas do Entity Framework Core, como ToListAsync.
using Microsoft.EntityFrameworkCore;
// Importa o contexto da base de dados da aplicação.
using Projeto.Data;
// Importa os modelos da aplicação, incluindo Race.
using Projeto.Models;

// Define que esta classe pertence ao namespace das páginas de corridas.
namespace Projeto.Pages.Races;

// Classe responsável pela lógica da página Index.cshtml, que lista todas as corridas.
public class IndexModel : PageModel
{
    // Contexto da base de dados usado para obter as corridas guardadas.
    private readonly ApplicationDbContext _context;

    // Construtor que recebe o contexto da base de dados por injeção de dependências.
    public IndexModel(ApplicationDbContext context)
    {
        // Guarda o contexto numa variável privada para ser usado no carregamento da página.
        _context = context;
    }

    // Lista de corridas que será preenchida no OnGetAsync e apresentada na tabela da página.
    public IList<Race> Races { get; set; } = new List<Race>();

    // Método executado quando o utilizador abre a página de listagem das corridas.
    public async Task OnGetAsync()
    {
        // Consulta a tabela de corridas na base de dados.
        Races = await _context.Races
            // Ordena as corridas pela data, para aparecerem de forma cronológica.
            .OrderBy(r => r.Date)
            // Executa a consulta e transforma o resultado numa lista de corridas.
            .ToListAsync();
    }
}
